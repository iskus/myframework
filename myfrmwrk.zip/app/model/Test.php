<?php
/**
 * Semesenko Anton. Email: iskus1981@yandex.ru 
 * IDE PhpStorm. 10.05.2015
 */

namespace app\model;

use core\Model;

class Test extends Model {

}