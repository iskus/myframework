<?php
	namespace app\view\shadow;
	use core\View as View;

	class Index extends View {
		public function createContent() {


			//parent::createContent();
		}
	}
