<?php

namespace app\view\shadow;



class Login extends Shadow {
	//public function createContent() {}

}