<?php
/**
 * Semesenko Anton. Email: iskus1981@yandex.ru 
 * IDE PhpStorm. 10.05.2015
 */

namespace app\view\shadow;


use core\View;

class Shadow extends View {
	public function __construct() {

		parent::__construct();
	}
}