<?php
	$scripts =
		[
			'jquery/jquery',
			'common'
		];