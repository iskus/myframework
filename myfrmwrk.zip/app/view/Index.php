<?php
	namespace app\view;
	use core\View as View;

	class Index extends View {
		public function createContent() {

            //
			parent::createContent();
		}
	}
